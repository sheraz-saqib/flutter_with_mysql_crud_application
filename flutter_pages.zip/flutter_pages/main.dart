import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_svg/flutter_svg.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber.shade500),
          useMaterial3: true,
          textTheme: TextTheme(
              headline1: TextStyle(
                  fontFamily: 'pop_bold', fontSize: 20, color: Colors.white))),
      home: const MyHomePage(title: 'flutter Application'),
    );
  }
}
class HexColor extends Color {
  static int _getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    return int.parse(hexColor, radix: 16);
  }

  HexColor(final String hexColor) : super(_getColorFromHex(hexColor));
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

extension StringCap on String {
  String cap() {
    return "${this[0].toUpperCase()}${this.substring(1)}";
  }
}

class _MyHomePageState extends State<MyHomePage> {
  DateTime _date = DateTime.now();
  var contr_data = TextEditingController();
  @override
  Widget build(BuildContext context) {

    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(

        body:
            SingleChildScrollView(
              child: Column(
                children: [
                  Container(height: 47,),
                  TopBar(),
                  Story(),
                  Divider(color:Colors.grey[300] ,),
                  postCard(5,'sheraz_coder','subhan_samma',5,'Ali_hamza',2,4,7),
                  postCard(2,'subhan_samma','shahzaib_khan',8,'Ali_hamza',1,2,12),
                  postCard(3,'Umair_javeed','khan_23',13,'umer_343',4,2,10),
                  // bottom_bar()
 

                ],
              ),
            ),



    );



  }
  Widget TopBar() {
    return Padding(
      padding: const EdgeInsets.only(left: 12,right: 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,

        children: [

          Container(
            width: 117,
            child: SvgPicture.asset('asset/image/Instagram.svg'),),
          Container(
            width: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(width: 24,child: SvgPicture.asset('asset/image/Like.svg'),),
                Container(width: 22,child: SvgPicture.asset('asset/image/Messenger.svg',),)
              ],
            ),
          )
        ],
      ),
    );
  }
  Widget story_profile(int index,String userName){
    return Padding(
      padding: const EdgeInsets.only(left: 5,right: 5),
      child: Container(child: Column(children: [
        Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [HexColor('#f9ce34'),HexColor('#ee2a7b'),HexColor('#6228d7')],
                begin: Alignment.bottomLeft,
                end: Alignment.centerRight,
                // stops: [0.1,0.2,0.1]

              ),
              borderRadius: BorderRadius.circular(50)
          ),
          child: Container(

            child: Padding(

              padding: const EdgeInsets.all(3.0),
              child: Container(decoration: BoxDecoration(
                  border: Border.all(
                      color: Colors.white,
                      width: 2
                  ),
                  borderRadius: BorderRadius.circular(50)

              ),child: CircleAvatar(radius: 35,backgroundImage: AssetImage('asset/image/$index.jpg'),)),
            ),
          ),),
        Container(
          margin: EdgeInsets.only(top: 5),
          child: Text(userName,style: TextStyle(color: Colors.grey[900]),),)
      ],),),
    );
  }
  Widget Story(){
    return
      Container(
        margin: EdgeInsets.only(top: 15),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Container(
            child: Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15,right: 5),
                child: Container(child: Column(children: [
                  Container(child: CircleAvatar( radius: 35,backgroundImage: AssetImage('asset/image/1.jpg'),),),
                  Container(
                    margin: EdgeInsets.only(top: 5),
                    child: Text('Your story',style: TextStyle(color: Colors.grey[600]),),)
                ],),),
              ),
              story_profile(2,'sheraz_coder'),
              story_profile(3,'umer'),
              story_profile(4,'umair'),
              story_profile(5,'ali khan'),
              story_profile(6,'subhan'),

            ],

    ),
          ),
        ),
      );
  }
  Widget postCard(int post_img,String userName,String likeBy,int profile_img,String fav,img1,img2,img3){
    return Column(
      children: [
        Container(child:
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 12,right: 12),
              child: Row(
                children: [
                  Container(child: CircleAvatar(radius: 17,backgroundImage: AssetImage('asset/image/$profile_img.jpg'),),),
                  Container(margin: EdgeInsets.only(left: 8),child: Text(userName,style: TextStyle(fontWeight: FontWeight.w800,fontSize: 15),),)
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 12,right: 12),
              child: Row(
                children: [
                  Container(child:
                  SvgPicture.asset('asset/image/More options.svg')
                    ,
                  ),

                ],
              ),
            ),

          ],
        )),
        Container(
          // width: 200,
          margin: EdgeInsets.only(top: 10),
          child: Image.asset('asset/image/$post_img.jpg'),
        ),
        Container(
          margin: EdgeInsets.only(top: 15),
          child: Padding(
            padding: const EdgeInsets.only(left: 12,right: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 100,
                  child: Row(
                    mainAxisAlignment:MainAxisAlignment.spaceBetween ,
                    children: [
                      Container(child: SvgPicture.asset('asset/image/Like.svg'),),
                      Container(child: SvgPicture.asset('asset/image/Comment.svg'),),
                      Container(child: SvgPicture.asset('asset/image/Share Post-1.svg'),),
                    ],
                  ),
                ),
                Container(child: SvgPicture.asset('asset/image/Save.svg'),),

              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 10,left: 12),
          child: Column(
            children: [
              Container(

                child: Row(
                  children: [
                    Container(
                      width: 45,
                      child: Stack(

                        children: [
                          Container(child: CircleAvatar(radius: 8,backgroundImage: AssetImage('asset/image/$img1.jpg'),),),
                          Container(margin: EdgeInsets.only(left: 11),child: CircleAvatar(radius: 8,backgroundImage: AssetImage('asset/image/$img2.jpg'),),),
                          Container(margin: EdgeInsets.only(left: 22),child: CircleAvatar(radius: 8,backgroundImage: AssetImage('asset/image/$img3.jpg'),),),
                        ],
                      ),
                    ),
                    Container(

                      child: Row(
                        children: [
                          Text('Liked by ',style: TextStyle(fontWeight: FontWeight.w500)),
                          Text(likeBy,style: TextStyle(fontWeight: FontWeight.w800),),
                          Text(' and',style: TextStyle(fontWeight: FontWeight.w500)),
                          Text(' others',style: TextStyle(fontWeight: FontWeight.w800)),
                        ],
                      )

                      ,)
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 4,bottom: 10),
                child:Row(
                  children: [
                    Text(fav,style: TextStyle(fontWeight: FontWeight.w800),),
                    Text(' Your favorite duo',style: TextStyle(fontWeight: FontWeight.w500),),

                  ],
                ) ,
              )
            ],
          ),
        )

      ],
    );
  }

  // Widget bottom_bar(){
  //   return
  //     BottomNavigationBar(items:[
  //       BottomNavigationBarItem(icon: Icon(Icons.add),label: 'Home'),
  //
  //     ])
  //     ;
  // }

}









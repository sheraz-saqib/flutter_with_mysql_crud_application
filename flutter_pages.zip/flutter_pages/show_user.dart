import 'dart:convert';
// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:my_first_app/update.dart';

class ShowUser extends StatefulWidget {
  const ShowUser({super.key});

  @override
  State<ShowUser> createState() => _ShowUserState();
}

class _ShowUserState extends State<ShowUser> {
  @override
  List<dynamic> data = [];
  int showCount = 0;
  bool _isLoad = true;
  Future<void> showData() async {
    try {
      final url = "http://192.168.2.103:81/application_api/show_data.php";

      final res = await http.get(Uri.parse(url));
      setState(() {
        data = jsonDecode(res.body);
        showCount = data.length;
        _isLoad = false;
      });
    } catch (e) {
      print(e);
    }
  }

  void succesMess(String message) {
    final snackBar = SnackBar(
      content: Text('$message'),
      action: SnackBarAction(
        label: "cancel",
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void errorMess(String message) {
    final snackBar = SnackBar(
      backgroundColor: const Color.fromARGB(255, 224, 82, 71),
      content: Text(
        '$message',
        style: TextStyle(color: Colors.white),
      ),
      action: SnackBarAction(
        textColor: Colors.white,
        label: "cancel",
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  Future<void> deleteUser(id) async {
    try {
      final url = "http://192.168.2.103:81/application_api/user_delete.php";

      final res = await http.post(Uri.parse(url), body: {"id": id});
      final response = jsonDecode(res.body);

      if (response["success"] == "true") {
        succesMess("user deleted ");
        showData();
      } else {
        errorMess("User not deleted");
      }
    } catch (e) {
      print(e);
      errorMess("User not deleted");
    }
  }

  initState() {
    // TODO: implement initState
    showData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(
              child:
                  Text("User List", style: TextStyle(fontFamily: "pop_bold"))),
          // backgroundColor: Color.fromARGB(255, 8, 201, 169),
        ),
        body: Visibility(
          visible: _isLoad,
          child: Center(
              child: CircularProgressIndicator(
            color: Colors.white,
          )),
          replacement: RefreshIndicator(
            onRefresh: showData,
            color: Colors.black,
            backgroundColor: Colors.white,
            child: ListView.builder(
              itemCount: showCount,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Card(
                    child: ListTile(
                        leading: CircleAvatar(
                          child: Text(
                            "${data[index]["user_name"][0].toString().toUpperCase()}",
                            style: TextStyle(fontSize: 19),
                          ),
                        ),
                        title: Text(
                            "${data[index]["user_name"].toString().trim()}"),
                        subtitle: Text(
                            "${data[index]["user_email"].toString().trim()}"),
                        trailing: PopupMenuButton(
                          itemBuilder: (context) {
                            return [
                              PopupMenuItem(
                                child: Text("Edit"),
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => UpdateUser(
                                            data[index]["user_id"],
                                            data[index]["user_name"],
                                            data[index]["user_email"],
                                            data[index]["user_password"]),
                                      ));
                                },
                              ),
                              PopupMenuItem(
                                child: Text("Delete"),
                                onTap: () {
                                  final id = data[index]["user_id"];
                                  deleteUser(id);
                                },
                              )
                            ];
                          },
                        )),
                  ),
                );
              },
            ),
          ),
        ));
  }
}

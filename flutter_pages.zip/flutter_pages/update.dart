import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UpdateUser extends StatefulWidget {
  // const UpdateUser({super.key});

  String User_id;
  String User_name;
  String User_email;
  String User_pass;

  UpdateUser(this.User_id, this.User_name, this.User_email, this.User_pass);

  @override
  State<UpdateUser> createState() => _UpdateUserState();
}

class _UpdateUserState extends State<UpdateUser> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController pass = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState

    name.text = widget.User_name;
    email.text = widget.User_email;
    pass.text = widget.User_pass;

    super.initState();
  }

  void succesMess(String message) {
    final snackBar = SnackBar(
      content: Text('$message'),
      action: SnackBarAction(
        label: "cancel",
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void errorMess(String message) {
    final snackBar = SnackBar(
      backgroundColor: const Color.fromARGB(255, 224, 82, 71),
      content: Text(
        '$message',
        style: TextStyle(color: Colors.white),
      ),
      action: SnackBarAction(
        textColor: Colors.white,
        label: "cancel",
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  Future<void> updateUser() async {
    try {
      if (name.text != "" && email.text != "" && pass.text != "") {
        String url = "http://192.168.2.103:81/application_api/userUpdate.php";
        var res = await http.post(Uri.parse(url), body: {
          "user_id": widget.User_id,
          "user_name": name.text,
          "user_email": email.text,
          "user_pass": pass.text,
        });

        var response = jsonDecode(res.body);
        if (response["success"] == "true") {
          succesMess("User update");
          Navigator.pop(context);
          
        } else {
          errorMess("not update");
        
        }
      } else {
        errorMess("fill out all field");
        
      }
    } catch (err) {
     
      errorMess("error");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(
              child:
                  Text("Edit User", style: TextStyle(fontFamily: "pop_bold"))),
          // backgroundColor: Color.fromARGB(255, 8, 201, 169),
        ),
        body: Center(
          child: Form(name, email, pass, updateUser),
        ));
  }
}

Widget Form(name, email, pass, dynamic funtion) {
  return Center(
    child: Container(
      width: 300,
      height: 330,
      decoration: BoxDecoration(
          color: Color.fromARGB(255, 94, 94, 94),
          borderRadius: BorderRadius.circular(10)),
      child: Center(
          child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Text(
              "User Edit",
              style: TextStyle(
                  fontFamily: "pop_medium",
                  fontSize: 18,
                  color: Color.fromARGB(255, 252, 252, 252)),
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 20, right: 20, top: 30, bottom: 15),
            child: Container(
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black26, width: 1),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(
                margin: EdgeInsets.only(left: 12),
                child: TextField(
                  controller: name,
                  style: TextStyle(
                    fontFamily: "pop_medium",
                  ),
                  cursorWidth: 1.5,
                  cursorColor: Colors.black12,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter Your Name",
                    helperStyle: TextStyle(fontWeight: FontWeight.w400),
                    suffixIcon: Icon(
                      Icons.person,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20, right: 20, bottom: 15),
            child: Container(
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black26, width: 1),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(
                margin: EdgeInsets.only(left: 12),
                child: TextField(
                  controller: email,
                  style: TextStyle(
                    fontFamily: "pop_medium",
                  ),
                  cursorWidth: 1.5,
                  cursorColor: Colors.black12,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter Your Email",
                    helperStyle: TextStyle(fontWeight: FontWeight.w400),
                    suffixIcon: Icon(
                      Icons.email_rounded,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Container(
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black26, width: 1),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(
                margin: EdgeInsets.only(left: 12),
                child: TextField(
                  controller: pass,
                  style: TextStyle(
                    fontFamily: "pop_medium",
                  ),
                  cursorWidth: 1.5,
                  cursorColor: Colors.black12,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter Your Password",
                    helperStyle: TextStyle(fontWeight: FontWeight.w400),
                    suffixIcon: Icon(
                      Icons.lock_open,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(5)),
              width: double.infinity,
              height: 42,
              child: InkWell(
                onTap: funtion,
                child: Center(
                    child: const Text(
                  "Update",
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: "pop_medium",
                      fontSize: 13),
                )),
              ),
            ),
          )
        ],
      )),
    ),
  );
}

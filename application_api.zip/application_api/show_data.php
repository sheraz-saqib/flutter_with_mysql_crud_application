<?php
require 'config.php';


$showDataQ = "select * from `user_list`";
$showData = mysqli_query($conn, $showDataQ);
$result = [];


while ($row = mysqli_fetch_assoc($showData)) {
    $result[] = ($row);
}

echo json_encode($result);

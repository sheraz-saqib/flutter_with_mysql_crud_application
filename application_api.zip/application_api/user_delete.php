<?php
require 'config.php';

$id = $_POST['id'];
$result = [];

if (isset($id)) {
    $deleteQ = "DELETE  FROM user_list WHERE user_id = $id";
    $delete = mysqli_query($conn, $deleteQ);
} else return;



if ($delete) {
    $result["success"] = "true";
} else {
    $result["success"] = "false";
}

echo json_encode($result);

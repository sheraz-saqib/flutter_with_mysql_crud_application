<?php
require 'config.php';

$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];
$user_pass = $_POST['user_pass'];

$result = [];

if (isset($_POST['user_name'])) {
    $user_name = $_POST['user_name'];
} else {
    return;
}
if (isset($_POST['user_email'])) {
    $user_email = $_POST['user_email'];
} else {
    return;
}
if (isset($_POST['user_pass'])) {
    $user_pass = $_POST['user_pass'];
} else {
    return;
}

$insertQ = "INSERT INTO `user_list`(`user_name`, `user_email`, `user_password`) 
    VALUES ('$user_name','$user_email','$user_pass')";

$insert = mysqli_query($conn, $insertQ);

if ($insert) {
    $result["result"] = "true";
} else {
    $result["result"] = "false";
}


echo json_encode($result);

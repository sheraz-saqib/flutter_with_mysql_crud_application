<?php
require 'config.php';
$user_id = trim($_POST['user_id']);
$user_name = trim($_POST['user_name']);
$user_email = trim($_POST['user_email']);
$user_pass =  trim($_POST['user_pass']);


$result = [];

if (isset($user_id) && isset($user_name) && isset($user_email) && isset($user_pass)) {

    $updateQ = "UPDATE `user_list` SET `user_name`= '$user_name
    ',`user_email`='$user_email',`user_password`='$user_pass' WHERE `user_id`=$user_id";

    $update = mysqli_query($conn, $updateQ);

    if ($update) {
        $result["success"] = "true";
    } else {
        $result["success"] = "false";
    }
}

echo json_encode($result);

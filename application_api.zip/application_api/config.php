<?php
$conn = mysqli_connect("localhost", 'root', '', 'flutter_db');

if (!$conn) {
    echo "connection not established";
}
